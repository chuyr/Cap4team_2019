package com.example.ppg;

import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        AlertDialog.Builder personal=new AlertDialog.Builder(this);
        personal.setTitle("개인정보수집 동의");
        personal.setMessage("왈왈왈");
        personal.setPositiveButton("나갈거야", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Toast.makeText(getApplicationContext(), "안녕", Toast.LENGTH_LONG).show();
                finish();
            }
        });

                personal.setNegativeButton("안끝내", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Toast.makeText(getApplicationContext(),"다시",Toast.LENGTH_LONG).show();
                    }
                });

                personal.setNeutralButton("모름", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Toast.makeText(getApplicationContext(),"모름",Toast.LENGTH_LONG).show();
                    }
                });
                       personal.setCancelable(false);
                        personal.show();



        setContentView(R.layout.activity_main);

        Button button1 = (Button) findViewById(R.id.loginButton) ;
        final EditText editText_id = (EditText)findViewById(R.id.edit_id);


        button1.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View view) {

                String info_id_number = editText_id.getText().toString();

                // TODO : click event
                Intent intent=new Intent(MainActivity.this,Read_QR.class);

                intent.putExtra("info_id", info_id_number);


                startActivity(intent);
            }
        });
    }
}
