package com.example.ppg;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;



    public class Read_QR extends AppCompatActivity {
    private Button scan_btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_read__qr);




        scan_btn = (Button)findViewById(R.id.scan_button);
        final Activity activity = this;
        scan_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                IntentIntegrator integrator = new IntentIntegrator(activity);
                integrator.setDesiredBarcodeFormats(IntentIntegrator.QR_CODE_TYPES);
                integrator.setPrompt("Scan");
                integrator.setCameraId(0);
                integrator.setBeepEnabled(false);
                integrator.setBarcodeImageEnabled(false);
                integrator.initiateScan();

            }
        });


    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        Intent intent_from_main = getIntent();   // 데이터 수신
        String info_id_number = intent_from_main.getExtras().getString("info_id");
        IntentResult result = IntentIntegrator.parseActivityResult(requestCode,resultCode, data);
        if (result != null){
            if(result.getContents()==null){
                Toast.makeText(this, "You cancelled the scanning",Toast.LENGTH_LONG).show();
            }
            else {
                Toast.makeText(this, result.getContents(),Toast.LENGTH_LONG).show();
                Intent intent2=new Intent(Read_QR.this,Information.class);
                intent2.putExtra("info_id2", info_id_number);
                intent2.putExtra("info_pc", result.getContents());
                startActivity(intent2);

            }
        }

        else{
            super.onActivityResult(requestCode, resultCode, data);
        }

    }
}
