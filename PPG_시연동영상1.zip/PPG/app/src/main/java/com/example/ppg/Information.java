package com.example.ppg;

import android.content.Intent;
import android.os.Bundle;

import android.widget.TextView;

public class Information extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_information);

        TextView textview_id_number = (TextView)findViewById(R.id.textview_id_number);
        TextView textview_pc_number = (TextView)findViewById(R.id.textview_pc_number);


        Intent intent = getIntent();



        String info_id_number = intent.getExtras().getString("info_id2");
        textview_id_number.setText(info_id_number);

        String info_pc_number = intent.getExtras().getString("info_pc");
        textview_pc_number.setText(info_pc_number);

    }

}
