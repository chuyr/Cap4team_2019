package com.example.ppg;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button button1 = (Button) findViewById(R.id.loginButton) ;
        final EditText editText_id = (EditText)findViewById(R.id.edit_id);


        button1.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View view) {

                String info_id_number = editText_id.getText().toString();

                // TODO : click event
                Intent intent=new Intent(MainActivity.this,Read_QR.class);

                intent.putExtra("info_id", info_id_number);


                startActivity(intent);
            }
        });
    }
}
